public interface Displayable {
    public String[] toStringArray();
}
